package com.jttw.engine.reincarnation;

import net.minecraftforge.common.ForgeConfigSpec;

/**
 * Common config for reincarnation.
 */
public final class ReincarnationConfig {
    private ReincarnationConfig() {}

    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.IntValue THRESHOLD_TOTAL_POINTS;

    /**
     * Entity ids are optional. If set to a valid LivingEntity registry id, the engine will
     * auto-transform the player into that entity on reincarnation.
     */
    public static final ForgeConfigSpec.ConfigValue<String> ENTITY_CELESTIAL_PRIMATE;
    public static final ForgeConfigSpec.ConfigValue<String> ENTITY_YUAN_DI;
    public static final ForgeConfigSpec.ConfigValue<String> ENTITY_EYE_OF_HEAVEN;
    public static final ForgeConfigSpec.ConfigValue<String> ENTITY_THIRD_LOTUS_PRINCE;
    public static final ForgeConfigSpec.ConfigValue<String> ENTITY_MARSHAL_HEAVENLY_CANOPY;
    public static final ForgeConfigSpec.ConfigValue<String> ENTITY_GARUDA;
    public static final ForgeConfigSpec.ConfigValue<String> ENTITY_DRAGON;
    public static final ForgeConfigSpec.ConfigValue<String> ENTITY_NINE_TAILED_FOX;
    public static final ForgeConfigSpec.ConfigValue<String> ENTITY_BULL_DEMON;
    public static final ForgeConfigSpec.ConfigValue<String> ENTITY_CHILD_DEMON;
    public static final ForgeConfigSpec.ConfigValue<String> ENTITY_SAURIAN_DEMON_KING;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.push("reincarnation");

        THRESHOLD_TOTAL_POINTS = b
                .comment("Total alignment points required before death triggers reincarnation.")
                .defineInRange("thresholdTotalPoints", 300, 0, 1000000);

        b.push("entityMappings");
        b.comment("Optional entity ids for each reincarnation outcome. Leave blank to disable auto-transform.");

        ENTITY_CELESTIAL_PRIMATE = b.define("celestialPrimate", "");
        ENTITY_YUAN_DI = b.define("yuanDi", "");
        ENTITY_EYE_OF_HEAVEN = b.define("eyeOfHeaven", "");
        ENTITY_THIRD_LOTUS_PRINCE = b.define("thirdLotusPrince", "");
        ENTITY_MARSHAL_HEAVENLY_CANOPY = b.define("marshalHeavenlyCanopy", "");
        ENTITY_GARUDA = b.define("garuda", "");
        ENTITY_DRAGON = b.define("dragon", "");
        ENTITY_NINE_TAILED_FOX = b.define("nineTailedFox", "");
        ENTITY_BULL_DEMON = b.define("bullDemon", "");
        ENTITY_CHILD_DEMON = b.define("childDemon", "");
        ENTITY_SAURIAN_DEMON_KING = b.define("saurianDemonKing", "");

        b.pop();
        b.pop();

        SPEC = b.build();
    }
}
