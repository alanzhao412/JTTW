package com.jttw.engine.reincarnation;

import net.minecraftforge.common.ForgeConfigSpec;

/**
 * Final reincarnation forms (primary + secondary alignment).
 */
public enum ReincarnationOutcome {
    // Primordial-dominant
    CELESTIAL_PRIMATE("celestial_primate", ReincarnationConfig.ENTITY_CELESTIAL_PRIMATE),
    YUAN_DI("yuan_di", ReincarnationConfig.ENTITY_YUAN_DI),

    // Heavenly-dominant
    EYE_OF_HEAVEN("eye_of_heaven", ReincarnationConfig.ENTITY_EYE_OF_HEAVEN),
    THIRD_LOTUS_PRINCE("third_lotus_prince", ReincarnationConfig.ENTITY_THIRD_LOTUS_PRINCE),
    MARSHAL_HEAVENLY_CANOPY("marshal_of_the_heavenly_canopy", ReincarnationConfig.ENTITY_MARSHAL_HEAVENLY_CANOPY),

    // Spirit Beast-dominant
    GARUDA("garuda", ReincarnationConfig.ENTITY_GARUDA),
    DRAGON("dragon", ReincarnationConfig.ENTITY_DRAGON),
    NINE_TAILED_FOX("nine_tailed_fox", ReincarnationConfig.ENTITY_NINE_TAILED_FOX),

    // Yaoguai-dominant
    BULL_DEMON_KING("bull_demon_king", ReincarnationConfig.ENTITY_BULL_DEMON),
    CHILD_DEMON("child_demon", ReincarnationConfig.ENTITY_CHILD_DEMON),
    SAURIAN_DEMON_KING("saurian_demon_king", ReincarnationConfig.ENTITY_SAURIAN_DEMON_KING);

    public final String id;
    private final ForgeConfigSpec.ConfigValue<String> entityIdConfig;

    ReincarnationOutcome(String id, ForgeConfigSpec.ConfigValue<String> entityIdConfig) {
        this.id = id;
        this.entityIdConfig = entityIdConfig;
    }

    /** Returns the configured entity id string, or blank if unset. */
    public String configuredEntityId() {
        String v = entityIdConfig.get();
        return v == null ? "" : v.trim();
    }
}
