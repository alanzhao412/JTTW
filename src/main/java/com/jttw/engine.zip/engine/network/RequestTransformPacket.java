package com.jttw.engine.network;

import com.jttw.engine.transformation.TransformationManager;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.registries.ForgeRegistries;

import java.util.function.Supplier;

public class RequestTransformPacket {

    public enum Kind {
        ENTITY,          // living entities (your current behavior)
        OBJECT_ENTITY    // non-living entities (arrows, minecarts, items, etc.)
    }

    private final Kind kind;
    private final ResourceLocation entityId;

    public RequestTransformPacket(Kind kind, ResourceLocation entityId) {
        this.kind = kind;
        this.entityId = entityId;
    }

    public static void encode(RequestTransformPacket msg, FriendlyByteBuf buf) {
        buf.writeVarInt(msg.kind.ordinal());
        buf.writeResourceLocation(msg.entityId);
    }

    public static RequestTransformPacket decode(FriendlyByteBuf buf) {
        int ord = buf.readVarInt();
        Kind kind = (ord >= 0 && ord < Kind.values().length) ? Kind.values()[ord] : Kind.ENTITY;
        return new RequestTransformPacket(kind, buf.readResourceLocation());
    }

    public static void handle(RequestTransformPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();

        final ServerPlayer sender = ctx.getSender();
        if (sender == null) {
            ctx.setPacketHandled(true);
            return;
        }

        ctx.enqueueWork(() -> {
            EntityType<?> type = ForgeRegistries.ENTITY_TYPES.getValue(msg.entityId);
            if (type == null) return;

            // Never allow player
            if (type == EntityType.PLAYER) return;

            Entity created = type.create(sender.serverLevel());
            if (created == null) return;

            boolean isLiving = (created instanceof LivingEntity);

            // Validate based on requested kind
            if (msg.kind == Kind.ENTITY) {
                if (!isLiving) return;
            } else if (msg.kind == Kind.OBJECT_ENTITY) {
                if (isLiving) return;
            }

            // NOTE: this next call currently assumes “living morph” in your TransformationManager.
            // We’ll update TransformationManager/TransformationData/PlayerRendererMixin next so non-living works properly.
            TransformationManager.transform(sender, type);
        });

        ctx.setPacketHandled(true);
    }
}