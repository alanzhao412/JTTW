package com.jttw.engine.network;

import com.jttw.engine.JTTWEngine;
import com.jttw.engine.progression.ActivateAbilityPacket;
import com.jttw.engine.progression.SpendSkillPointPacket;
import com.jttw.engine.progression.SyncAbilitiesPacket;
import com.jttw.engine.progression.SyncCooldownPacket;
import com.jttw.engine.progression.SyncLevelPacket;
import com.jttw.engine.progression.SyncQiPacket;
import com.jttw.engine.progression.SyncSkillTreePacket;
import com.jttw.engine.reincarnation.SyncReincarnationPacket;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class NetworkHandler {

    private static final String PROTOCOL_VERSION = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.ChannelBuilder
        .named(ResourceLocation.fromNamespaceAndPath(JTTWEngine.MOD_ID, "main"))
        .networkProtocolVersion(() -> PROTOCOL_VERSION)
        .clientAcceptedVersions(PROTOCOL_VERSION::equals)
        .serverAcceptedVersions(PROTOCOL_VERSION::equals)
        .simpleChannel();

    private static int id = 0;

    private NetworkHandler() {}

    public static void register() {
        // PLAY_TO_CLIENT
        CHANNEL.messageBuilder(SyncTransformationPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncTransformationPacket::encode)
                .decoder(SyncTransformationPacket::decode)
                .consumerMainThread(SyncTransformationPacket::handle)
                .add();

        CHANNEL.messageBuilder(OpenTransformationMenuPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(OpenTransformationMenuPacket::encode)
                .decoder(OpenTransformationMenuPacket::decode)
                .consumerMainThread(OpenTransformationMenuPacket::handle)
                .add();

        CHANNEL.messageBuilder(SyncLevelPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncLevelPacket::encode)
                .decoder(SyncLevelPacket::decode)
                .consumerMainThread(SyncLevelPacket::handle)
                .add();

        CHANNEL.messageBuilder(SyncAbilitiesPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncAbilitiesPacket::encode)
                .decoder(SyncAbilitiesPacket::decode)
                .consumerMainThread(SyncAbilitiesPacket::handle)
                .add();

        CHANNEL.messageBuilder(SyncCooldownPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncCooldownPacket::encode)
                .decoder(SyncCooldownPacket::decode)
                .consumerMainThread(SyncCooldownPacket::handle)
                .add();

        CHANNEL.messageBuilder(SyncSkillTreePacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncSkillTreePacket::encode)
                .decoder(SyncSkillTreePacket::decode)
                .consumerMainThread(SyncSkillTreePacket::handle)
                .add();

        CHANNEL.messageBuilder(SyncQiPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncQiPacket::encode)
                .decoder(SyncQiPacket::decode)
                .consumerMainThread(SyncQiPacket::handle)
                .add();

        CHANNEL.messageBuilder(SyncReincarnationPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncReincarnationPacket::encode)
                .decoder(SyncReincarnationPacket::decode)
                .consumerMainThread(SyncReincarnationPacket::handle)
                .add();

        // ✅ NEW: ring visual state sync (server → client)
        CHANNEL.messageBuilder(com.jttw.engine.progression.SyncRingStatePacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(com.jttw.engine.progression.SyncRingStatePacket::encode)
                .decoder(com.jttw.engine.progression.SyncRingStatePacket::decode)
                .consumerMainThread(com.jttw.engine.progression.SyncRingStatePacket::handle)
                .add();

        // Eye of Heaven state sync (server → client)
        CHANNEL.messageBuilder(SyncEyeOfHeavenPacket.class, id++, NetworkDirection.PLAY_TO_CLIENT)
                .encoder(SyncEyeOfHeavenPacket::encode)
                .decoder(SyncEyeOfHeavenPacket::decode)
                .consumerMainThread(SyncEyeOfHeavenPacket::handle)
                .add();

        // PLAY_TO_SERVER
        CHANNEL.messageBuilder(SpendSkillPointPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(SpendSkillPointPacket::encode)
                .decoder(SpendSkillPointPacket::decode)
                .consumerMainThread(SpendSkillPointPacket::handle)
                .add();

        CHANNEL.messageBuilder(ActivateAbilityPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(ActivateAbilityPacket::encode)
                .decoder(ActivateAbilityPacket::decode)
                .consumerMainThread(ActivateAbilityPacket::handle)
                .add();

        CHANNEL.messageBuilder(RequestTransformPacket.class, id++, NetworkDirection.PLAY_TO_SERVER)
                .encoder(RequestTransformPacket::encode)
                .decoder(RequestTransformPacket::decode)
                .consumerMainThread(RequestTransformPacket::handle)
                .add();
    }

    public static void sendToServer(Object msg) {
        CHANNEL.sendToServer(msg);
    }

    public static void sendToPlayer(ServerPlayer player, Object msg) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), msg);
    }

    public static void sendToTrackingPlayers(ServerPlayer player, Object msg) {
        CHANNEL.send(PacketDistributor.TRACKING_ENTITY.with(() -> player), msg);
    }
}