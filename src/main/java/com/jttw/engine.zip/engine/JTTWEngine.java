package com.jttw.engine;

import com.jttw.engine.commands.AlignmentDebugCommand;
import com.jttw.engine.commands.LevelDebugCommand;
import com.jttw.engine.commands.SetClassCommand;
import com.jttw.engine.commands.SkillPointDebugCommand;
import com.jttw.engine.commands.TransformCommand;
import com.jttw.engine.progression.WuCloneEntity;
import com.jttw.engine.progression.XiaotianQuanEntity;
import com.jttw.engine.reincarnation.ReincarnationConfig;
import com.jttw.engine.network.NetworkHandler;
import com.jttw.engine.transformation.TransformationManager;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Mod(JTTWEngine.MOD_ID)
public class JTTWEngine {
    public static final String MOD_ID = "jttw_engine";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // ── Entity registry ────────────────────────────────────────────
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MOD_ID);

    public static final RegistryObject<EntityType<WuCloneEntity>> WU_CLONE =
            ENTITIES.register("wu_clone", () ->
                    EntityType.Builder.<WuCloneEntity>of(WuCloneEntity::new, MobCategory.MISC)
                            .sized(0.6F, 1.8F)
                            .clientTrackingRange(10)
                            .build(new ResourceLocation(MOD_ID, "wu_clone").toString()));

    public static final RegistryObject<EntityType<XiaotianQuanEntity>> XIAOTIAN_QUAN =
            ENTITIES.register("xiaotian_quan", () ->
                    EntityType.Builder.<XiaotianQuanEntity>of(XiaotianQuanEntity::new, MobCategory.MISC)
                            .sized(0.6F, 0.85F)
                            .clientTrackingRange(10)
                            .build(new ResourceLocation(MOD_ID, "xiaotian_quan").toString()));

    public JTTWEngine() {
        @SuppressWarnings("removal")
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();

        // Entity registry
        ENTITIES.register(modEventBus);

        // Register setup
        modEventBus.addListener(this::commonSetup);

        // Entity attributes (MOD bus)
        modEventBus.addListener(JTTWEngine::onAttributeCreate);

        // Register to the Forge event bus
        MinecraftForge.EVENT_BUS.register(this);

        // Transformation events live on the class
        MinecraftForge.EVENT_BUS.register(TransformationManager.class);

        // Wukong ability server tick & logout cleanup
        MinecraftForge.EVENT_BUS.register(com.jttw.engine.progression.WukongAbilityHandler.class);

        // Wukong shadow clone server-side manager
        MinecraftForge.EVENT_BUS.register(com.jttw.engine.progression.WuCloneManager.class);

        // Erlang Shen ability handlers
        MinecraftForge.EVENT_BUS.register(com.jttw.engine.progression.XiaotianQuanManager.class);
        MinecraftForge.EVENT_BUS.register(com.jttw.engine.progression.ErlangShenAbilityHandler.class);

        // Config
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, ReincarnationConfig.SPEC);

        LOGGER.info("JTTW Engine initialized!");
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(() -> {
            NetworkHandler.register();
            LOGGER.info("Network handlers registered");
        });
    }

    // ── Attribute registration (MOD bus) ───────────────────────────
    public static void onAttributeCreate(EntityAttributeCreationEvent event) {
        event.put(WU_CLONE.get(), WuCloneEntity.createAttributes().build());
        event.put(XIAOTIAN_QUAN.get(), XiaotianQuanEntity.createAttributes().build());
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        TransformCommand.register(event.getDispatcher());
        AlignmentDebugCommand.register(event.getDispatcher());
        LevelDebugCommand.register(event.getDispatcher());
        SkillPointDebugCommand.register(event.getDispatcher());
        SetClassCommand.register(event.getDispatcher());
        LOGGER.info("Commands registered");
    }

    @SubscribeEvent
    public void onPlayerLoggedIn(PlayerEvent.PlayerLoggedInEvent event) {
        TransformationManager.syncToClient(event.getEntity());
    }

    @SubscribeEvent
    public void onPlayerClone(PlayerEvent.Clone event) {
        if (event.isWasDeath()) {
            TransformationManager.copyTransformationData(event.getOriginal(), event.getEntity());
        }
    }
}