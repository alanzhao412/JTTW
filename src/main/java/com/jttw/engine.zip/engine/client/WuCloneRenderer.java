package com.jttw.engine.client;

import com.jttw.engine.progression.WuCloneEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.resources.DefaultPlayerSkin;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.UUID;

/**
 * Renders WuCloneEntity using the owning player's skin.
 * Uses the standard HumanoidModel (player body proportions, arms down).
 * The owner UUID is read from the entity's custom name ("jttw_clone:<uuid>").
 */
@OnlyIn(Dist.CLIENT)
public class WuCloneRenderer extends HumanoidMobRenderer<WuCloneEntity, HumanoidModel<WuCloneEntity>> {

    private static final String PREFIX = "jttw_clone:";

    public WuCloneRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(WuCloneEntity entity) {
        Component name = entity.getCustomName();
        if (name != null) {
            String s = name.getString();
            if (s.startsWith(PREFIX)) {
                try {
                    UUID ownerId = UUID.fromString(s.substring(PREFIX.length()));
                    Minecraft mc = Minecraft.getInstance();
                    if (mc.level != null) {
                        Player player = mc.level.getPlayerByUUID(ownerId);
                        if (player instanceof AbstractClientPlayer owner) {
                            return owner.getSkinTextureLocation();
                        }
                    }
                    return DefaultPlayerSkin.getDefaultSkin(ownerId);
                } catch (IllegalArgumentException ignored) {}
            }
        }
        return DefaultPlayerSkin.getDefaultSkin(entity.getUUID());
    }
}