package com.jttw.engine.client.model;

import com.jttw.engine.JTTWEngine;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;

public class fire_ring<T extends Entity> extends EntityModel<T> {

    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(
                    ResourceLocation.fromNamespaceAndPath(JTTWEngine.MOD_ID, "fire_ring"), "main");

    private final ModelPart fire_rune;
    private final ModelPart inside;

    public fire_ring(ModelPart root) {
        this.fire_rune = root.getChild("fire_rune");
        this.inside    = root.getChild("inside");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.getRoot();

        // 64×64 texture sheet (matching Blockbench project settings).
        // Box is 64 wide × 1 tall × 64 deep so it has actual faces to render.
        // texOffs(0, 0): top-left of your texture maps to the top face of the box.
        partdefinition.addOrReplaceChild(
                "fire_rune",
                CubeListBuilder.create()
                        .texOffs(0, 0)
                        .addBox(-32.0F, -1.0F, -32.0F, 64, 1, 64, new CubeDeformation(0.0F)),
                PartPose.offset(0.0F, 24.0F, 0.0F)
        );

        // inside shares the same UV island — it counter-rotates so the two
        // layers create a spinning rune effect on top of each other.
        partdefinition.addOrReplaceChild(
                "inside",
                CubeListBuilder.create()
                        .texOffs(0, 0)
                        .addBox(-32.0F, -1.0F, -32.0F, 64, 1, 64, new CubeDeformation(0.0F)),
                PartPose.offset(0.0F, 24.0F, 0.0F)
        );

        return LayerDefinition.create(meshdefinition, 64, 64);
    }

    @Override
    public void setupAnim(T entity, float limbSwing, float limbSwingAmount,
                          float ageInTicks, float netHeadYaw, float headPitch) {
        fire_rune.yRot =  ageInTicks * 0.01F;
        inside.yRot    = -ageInTicks * 0.015F;
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer vertexConsumer,
                               int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        fire_rune.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
        inside.render(poseStack, vertexConsumer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}