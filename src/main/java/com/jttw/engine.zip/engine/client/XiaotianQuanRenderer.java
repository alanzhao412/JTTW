package com.jttw.engine.client;

import com.jttw.engine.progression.XiaotianQuanEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

/**
 * Renders Xiaotian Quan using a humanoid model as a placeholder.
 *
 * <p>WolfModel requires {@code T extends Wolf} which prevents direct use.
 * This uses a humanoid model (same as WuCloneRenderer) with the default
 * player skin. Replace with a custom quadruped model + wolf texture later.
 */
@OnlyIn(Dist.CLIENT)
public class XiaotianQuanRenderer extends HumanoidMobRenderer<XiaotianQuanEntity, HumanoidModel<XiaotianQuanEntity>> {

    private static final ResourceLocation TEXTURE =
            net.minecraft.client.resources.DefaultPlayerSkin.getDefaultSkin();

    public XiaotianQuanRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(XiaotianQuanEntity entity) {
        return TEXTURE;
    }
}
