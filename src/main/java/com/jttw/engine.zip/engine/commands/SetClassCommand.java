package com.jttw.engine.commands;

import com.jttw.engine.network.NetworkHandler;
import com.jttw.engine.progression.*;
import com.jttw.engine.reincarnation.AlignmentData;
import com.jttw.engine.reincarnation.ReincarnationOutcome;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

/**
 * Debug command to forcibly set a player's class, subclass outcome, and skill points.
 *
 * <p>Usage:
 * <pre>
 *   /jttw_setclass primordial     — sets class to PRIMORDIAL + outcome CELESTIAL_PRIMATE
 *   /jttw_setclass heavenly       — sets class to HEAVENLY   + outcome MARSHAL_HEAVENLY_CANOPY
 *   /jttw_setclass divine_beast   — sets class to DIVINE_BEAST + outcome DRAGON
 *   /jttw_setclass yaoguai        — sets class to YAOGUAI    + outcome BULL_DEMON_KING
 * </pre>
 *
 * <p>Also grants 20 skill points and resets to level 1 so the skill tree is fully
 * accessible for testing without going through the reincarnation ritual.
 */
public class SetClassCommand {

    private SetClassCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
            Commands.literal("jttw_setclass")
                .requires(src -> src.hasPermission(2))
                .then(Commands.argument("class", StringArgumentType.word())
                    .executes(ctx -> {
                        ServerPlayer player = ctx.getSource().getPlayerOrException();
                        String arg = StringArgumentType.getString(ctx, "class").toLowerCase();
                        return applyClass(player, arg, ctx.getSource());
                    })
                )
        );
    }

    private static int applyClass(ServerPlayer player, String arg, CommandSourceStack src) {
        ProgressionClass cls;
        ReincarnationOutcome outcome;

        switch (arg) {
            case "primordial" -> {
                cls     = ProgressionClass.PRIMORDIAL;
                outcome = ReincarnationOutcome.CELESTIAL_PRIMATE;
            }
            case "heavenly" -> {
                cls     = ProgressionClass.HEAVENLY;
                outcome = ReincarnationOutcome.MARSHAL_HEAVENLY_CANOPY;
            }
            case "divine_beast", "divinebeast" -> {
                cls     = ProgressionClass.DIVINE_BEAST;
                outcome = ReincarnationOutcome.DRAGON;
            }
            case "yaoguai" -> {
                cls     = ProgressionClass.YAOGUAI;
                outcome = ReincarnationOutcome.BULL_DEMON_KING;
            }
            default -> {
                src.sendFailure(Component.literal(
                    "Unknown class: " + arg + ". Use: primordial | heavenly | divine_beast | yaoguai"));
                return 0;
            }
        }

        // Set progression class + reincarnation outcome (both needed for ability routing)
        PlayerLevel.setProgressionClass(player, cls);
        AlignmentData.markReincarnated(player, outcome);

        // Reset to level 1, grant 20 skill points for full testing
        PlayerLevel.setLevel(player, 1);
        PlayerLevel.setXp(player, 0L);
        SkillTreeData.setPoints(player, 20);

        // Apply base stats
        LevelManager.reapplyStats(player);

        // Sync everything to the client
        LevelManager.syncToClient(player);

        src.sendSuccess(() -> Component.literal(
            "§6[JTTW] §rClass set to §e" + cls.name() +
            " §r(outcome: §b" + outcome.id + "§r). §a20 skill points granted. Open skill tree with K."
        ), false);

        return 1;
    }
}