package com.jttw.engine.flight;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

public final class ClientFlightHandler {

    private ClientFlightHandler() {}

    private static final double FLIGHT_SPEED = 1.55;
    private static final double FLIGHT_FLEX_PER_TICK = 0.12;
    private static final double FLIGHT_STRAFE_SCALE = 0.85;

    private static final double MAX_Y  = 1.75;
    private static final double MAX_XZ = 2.25;

    // Palladium-style decay: boost drops 0.1/tick from max 1.0 → ~10 ticks to stop
    // Equivalent per-tick velocity multiplier ≈ 0.9
    private static final double NO_INPUT_DECAY = 0.92;
    private static final double NO_INPUT_CUTOFF_SQR = 0.001; // stop when negligible

    // Same decay used after flight ends so the glide feels identical
    private static final double LANDING_DECAY = 0.9;

    private static Vec3 flightVector = Vec3.ZERO;
    private static Vec3 landingMomentum = Vec3.ZERO;
    private static boolean wasFlying = false;

    private static Vec3 clampSpeed(Vec3 v) {
        double xz = Math.sqrt(v.x * v.x + v.z * v.z);
        if (xz > MAX_XZ && xz > 1.0e-9) {
            double s = MAX_XZ / xz;
            v = new Vec3(v.x * s, v.y, v.z * s);
        }
        v = new Vec3(v.x, Mth.clamp(v.y, -MAX_Y, MAX_Y), v.z);
        return v;
    }

    public static void tick(Minecraft mc) {
        LocalPlayer p = mc.player;
        if (p == null) return;
        if (p.isCreative() || p.isSpectator()) return;

        if (!p.getAbilities().flying) {
            // First tick after flight ends: capture whatever velocity we had
            if (wasFlying) {
                landingMomentum = flightVector;
                flightVector = Vec3.ZERO;
                wasFlying = false;
            }

            // Apply and decay landing momentum so the player glides a few blocks
            if (landingMomentum.lengthSqr() > NO_INPUT_CUTOFF_SQR) {
                p.setDeltaMovement(landingMomentum);
                landingMomentum = landingMomentum.scale(LANDING_DECAY);
            } else {
                landingMomentum = Vec3.ZERO;
            }
            return;
        }

        wasFlying = true;

        double forward = p.zza;
        double strafe  = p.xxa;

        boolean hasMoveInput = (Math.abs(forward) > 0.01) || (Math.abs(strafe) > 0.01);

        // CHANGED: apply decay instead of stopping instantly
        if (!hasMoveInput) {
            flightVector = flightVector.scale(NO_INPUT_DECAY);

            if (flightVector.lengthSqr() < NO_INPUT_CUTOFF_SQR) {
                flightVector = Vec3.ZERO;
            }

            p.setDeltaMovement(flightVector);
            return;
        }

        Vec3 look = p.getLookAngle().normalize();
        Vec3 desired = look.scale(forward * FLIGHT_SPEED);

        Vec3 lookFlat = new Vec3(look.x, 0, look.z);
        if (lookFlat.lengthSqr() < 1.0e-9) lookFlat = new Vec3(0, 0, 1);
        lookFlat = lookFlat.normalize();

        Vec3 right = new Vec3(lookFlat.z, 0, -lookFlat.x).normalize();
        desired = desired.add(right.scale(strafe * FLIGHT_SPEED * FLIGHT_STRAFE_SCALE));

        Vec3 delta = desired.subtract(flightVector);
        double deltaLen = delta.length();
        if (deltaLen > FLIGHT_FLEX_PER_TICK && deltaLen > 1.0e-9) {
            delta = delta.scale(FLIGHT_FLEX_PER_TICK / deltaLen);
        }

        flightVector = flightVector.add(delta);
        flightVector = clampSpeed(flightVector);

        p.setDeltaMovement(flightVector);
    }
}