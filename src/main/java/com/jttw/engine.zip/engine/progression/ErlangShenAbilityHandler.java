package com.jttw.engine.progression;

import com.jttw.engine.JTTWEngine;
import com.jttw.engine.network.NetworkHandler;
import com.jttw.engine.network.SyncEyeOfHeavenPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Server-side handler for Erlang Shen's Eye of Heaven ability.
 *
 * <p>The Eye is a TOGGLE ability that drains Qi while active.
 * Visual effects (ore highlighting, username reveal) are entirely client-side;
 * the server just manages Qi drain and tells the client on/off + tier.
 */
@Mod.EventBusSubscriber(modid = JTTWEngine.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ErlangShenAbilityHandler {

    private ErlangShenAbilityHandler() {}

    private static final Set<UUID> ACTIVE_EYES = new HashSet<>();

    private static final float QI_DRAIN_PER_TICK_BASE = 0.08f; // Tier 1-2
    private static final float QI_DRAIN_PER_TICK_T3   = 0.05f; // Tier 3 (reduced)

    // =========================================================================
    // Public API
    // =========================================================================

    public static void toggleEye(ServerPlayer player) {
        if (ACTIVE_EYES.contains(player.getUUID())) {
            stopEye(player);
        } else {
            startEye(player);
        }
    }

    public static boolean isActive(UUID playerId) {
        return ACTIVE_EYES.contains(playerId);
    }

    // =========================================================================
    // Internal
    // =========================================================================

    private static void startEye(ServerPlayer player) {
        int tier = SkillTreeData.getEyeTier(player);
        if (tier < 1) return;
        ACTIVE_EYES.add(player.getUUID());
        NetworkHandler.sendToPlayer(player,
                new SyncEyeOfHeavenPacket(player.getUUID(), true, tier));
    }

    private static void stopEye(ServerPlayer player) {
        ACTIVE_EYES.remove(player.getUUID());
        NetworkHandler.sendToPlayer(player,
                new SyncEyeOfHeavenPacket(player.getUUID(), false, 0));
    }

    // =========================================================================
    // Tick — Qi drain
    // =========================================================================

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        MinecraftServer server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;

        Set<UUID> toRemove = new HashSet<>();

        for (UUID uuid : ACTIVE_EYES) {
            ServerPlayer player = server.getPlayerList().getPlayer(uuid);
            if (player == null) {
                toRemove.add(uuid);
                continue;
            }

            int tier = SkillTreeData.getEyeTier(player);
            float drain = (tier >= 3) ? QI_DRAIN_PER_TICK_T3 : QI_DRAIN_PER_TICK_BASE;

            if (!QiData.spend(player, drain)) {
                toRemove.add(uuid);
                NetworkHandler.sendToPlayer(player,
                        new SyncEyeOfHeavenPacket(uuid, false, 0));
                continue;
            }

            // Periodic Qi sync
            if (player.tickCount % 10 == 0) {
                NetworkHandler.sendToPlayer(player,
                        new SyncQiPacket(QiData.getCurrent(player), QiData.getMax(player)));
            }
        }

        ACTIVE_EYES.removeAll(toRemove);
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        ACTIVE_EYES.remove(event.getEntity().getUUID());
    }
}
