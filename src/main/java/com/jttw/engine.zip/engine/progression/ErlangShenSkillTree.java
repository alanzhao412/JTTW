package com.jttw.engine.progression;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Defines Erlang Shen's (EYE_OF_HEAVEN) complete skill tree.
 *
 * <p><b>Tree layout — 6 columns, 3 rows max:</b>
 * <pre>
 * Col:    0 (Transforms)  1 (Xiaotian Quan)  2 (Eye of Heaven)  3 (Flight)  4 (Qi)  5 (Hound Growth)
 *
 * Row 0:  Transform I     XTQ I              Eye I              Cloud Step  Qi I    Hound Training I
 * Row 1:  Transform II    XTQ II             Eye II             Nimbus      Qi II   Hound Training II
 * Row 2:  Transform III   XTQ III            Eye III            Somersault          Hound Training III
 * </pre>
 *
 * <p>Players earn 1 skill point every 5 levels (max 20 at level 100).
 */
public final class ErlangShenSkillTree {

    private ErlangShenSkillTree() {}

    // -----------------------------------------------------------------------
    // Node ID constants — use these in gameplay checks
    // -----------------------------------------------------------------------

    public static final String TRANSFORM_1  = "es_transform_1";
    public static final String TRANSFORM_2  = "es_transform_2";
    public static final String TRANSFORM_3  = "es_transform_3";

    public static final String XTQ_1        = "es_xtq_1";
    public static final String XTQ_2        = "es_xtq_2";
    public static final String XTQ_3        = "es_xtq_3";

    public static final String EYE_1        = "es_eye_1";
    public static final String EYE_2        = "es_eye_2";
    public static final String EYE_3        = "es_eye_3";

    public static final String FLIGHT_1     = "es_flight_1";
    public static final String FLIGHT_2     = "es_flight_2";
    public static final String FLIGHT_3     = "es_flight_3";

    public static final String QI_1         = "es_qi_1";
    public static final String QI_2         = "es_qi_2";

    public static final String XTQ_GROWTH_1 = "es_xtq_growth_1";
    public static final String XTQ_GROWTH_2 = "es_xtq_growth_2";
    public static final String XTQ_GROWTH_3 = "es_xtq_growth_3";

    // -----------------------------------------------------------------------
    // Registry
    // -----------------------------------------------------------------------

    private static final Map<String, SkillNode> NODES = new LinkedHashMap<>();

    static {
        // ── 72 TRANSFORMATIONS (col 0, MENU type) ─────────────────────
        reg(new SkillNode(
                TRANSFORM_1, "72 Transformations I",
                new String[]{ "Press R to open the", "Transformation Menu.",
                              "Ground & water mobs only." },
                3, 0, 0, List.of(), AbilityType.MENU, 1, "Transformations"
        ));
        reg(new SkillNode(
                TRANSFORM_2, "72 Transformations II",
                new String[]{ "Unlocks flying mob forms.", "Transform your equipped",
                              "items into same-tier variants." },
                4, 0, 1, List.of(TRANSFORM_1), AbilityType.MENU, 2, "Transformations"
        ));
        reg(new SkillNode(
                TRANSFORM_3, "72 Transformations III",
                new String[]{ "Unlocks boss entity forms.", "Qi cost scales with",
                              "the size of the form." },
                5, 0, 2, List.of(TRANSFORM_2), AbilityType.MENU, 3, "Transformations"
        ));

        // ── XIAOTIAN QUAN (col 1, TOGGLE type) ────────────────────────
        reg(new SkillNode(
                XTQ_1, "Xiaotian Quan I",
                new String[]{ "Press F: summon your", "celestial hound companion.",
                              "Costs Qi to maintain." },
                3, 1, 0, List.of(), AbilityType.TOGGLE, 1, "Xiaotian Quan"
        ));
        reg(new SkillNode(
                XTQ_2, "Xiaotian Quan II",
                new String[]{ "Improved companion stats.", "Xiaotian Quan gains",
                              "tracking sense." },
                4, 1, 1, List.of(XTQ_1), AbilityType.TOGGLE, 2, "Xiaotian Quan"
        ));
        reg(new SkillNode(
                XTQ_3, "Xiaotian Quan III",
                new String[]{ "Peak hound power.", "Attacks apply Slowness.",
                              "Enhanced combat partner." },
                5, 1, 2, List.of(XTQ_2), AbilityType.TOGGLE, 3, "Xiaotian Quan"
        ));

        // ── EYE OF HEAVEN (col 2, TOGGLE type) ───────────────────────
        reg(new SkillNode(
                EYE_1, "Eye of Heaven I",
                new String[]{ "Press V: activate the", "Third Eye. See through",
                              "72 Transformations." },
                3, 2, 0, List.of(), AbilityType.TOGGLE, 1, "Eye of Heaven"
        ));
        reg(new SkillNode(
                EYE_2, "Eye of Heaven II",
                new String[]{ "Reveals ores through", "blocks within 16 blocks.",
                              "Color-coded by type." },
                4, 2, 1, List.of(EYE_1), AbilityType.TOGGLE, 2, "Eye of Heaven"
        ));
        reg(new SkillNode(
                EYE_3, "Eye of Heaven III",
                new String[]{ "Extended ore range (32).", "Reduced Qi drain.",
                              "True divine perception." },
                5, 2, 2, List.of(EYE_2), AbilityType.TOGGLE, 3, "Eye of Heaven"
        ));

        // ── FLIGHT (col 3, PASSIVE) ──────────────────────────────────
        reg(new SkillNode(
                FLIGHT_1, "Cloud Step",
                new String[]{ "Grants permanent flight.", "Hold Space to ascend.", "" },
                2, 3, 0, List.of(), AbilityType.PASSIVE, 1, "Flight"
        ));
        reg(new SkillNode(
                FLIGHT_2, "Nimbus Cloud",
                new String[]{ "Flight speed greatly", "increased. Somersault",
                              "cloud momentum physics." },
                3, 3, 1, List.of(FLIGHT_1), AbilityType.PASSIVE, 2, "Flight"
        ));
        reg(new SkillNode(
                FLIGHT_3, "Somersault Cloud",
                new String[]{ "Cycles Overworld/Nether/End", "while airborne.",
                              "" },
                4, 3, 2, List.of(FLIGHT_2), AbilityType.PASSIVE, 3, "Flight"
        ));

        // ── QI PASSIVES (col 4) ──────────────────────────────────────
        reg(new SkillNode(
                QI_1, "Qi Mastery I",
                new String[]{ "+25 max Qi.", "" },
                1, 4, 0, List.of(), AbilityType.PASSIVE, 0, "Qi Mastery"
        ));
        reg(new SkillNode(
                QI_2, "Qi Mastery II",
                new String[]{ "+25 max Qi.", "" },
                2, 4, 1, List.of(QI_1), AbilityType.PASSIVE, 0, "Qi Mastery"
        ));

        // ── HOUND GROWTH PASSIVES (col 5) ────────────────────────────
        reg(new SkillNode(
                XTQ_GROWTH_1, "Hound Training I",
                new String[]{ "Xiaotian Quan gains", "+20 HP, +3 ATK.", "" },
                2, 5, 0, List.of(), AbilityType.PASSIVE, 0, "Hound Growth"
        ));
        reg(new SkillNode(
                XTQ_GROWTH_2, "Hound Training II",
                new String[]{ "Xiaotian Quan gains", "tracking ability. +20 HP.", "" },
                3, 5, 1, List.of(XTQ_GROWTH_1), AbilityType.PASSIVE, 0, "Hound Growth"
        ));
        reg(new SkillNode(
                XTQ_GROWTH_3, "Hound Training III",
                new String[]{ "Peak stats. Attacks", "apply Slowness II.", "" },
                4, 5, 2, List.of(XTQ_GROWTH_2), AbilityType.PASSIVE, 0, "Hound Growth"
        ));
    }

    private static void reg(SkillNode node) {
        NODES.put(node.id(), node);
    }

    // -----------------------------------------------------------------------
    // Public API
    // -----------------------------------------------------------------------

    public static Map<String, SkillNode> getNodes() {
        return Collections.unmodifiableMap(NODES);
    }

    public static SkillNode get(String id) {
        return NODES.get(id);
    }

    /** Returns all nodes in the tree, ordered by col then row. */
    public static List<SkillNode> getAllOrdered() {
        List<SkillNode> list = new ArrayList<>(NODES.values());
        list.sort((a, b) -> a.col() != b.col() ? Integer.compare(a.col(), b.col())
                                                 : Integer.compare(a.row(), b.row()));
        return list;
    }

    /**
     * Returns the highest unlocked tier for the ability branch with the given root ID prefix.
     * E.g. prefix "es_xtq" checks es_xtq_1, _2, _3.
     */
    public static int getHighestTier(Set<String> unlockedNodeIds, String idPrefix) {
        int tier = 0;
        for (SkillNode node : NODES.values()) {
            if (node.id().startsWith(idPrefix) && unlockedNodeIds.contains(node.id())) {
                tier = Math.max(tier, node.tier());
            }
        }
        return tier;
    }
}
