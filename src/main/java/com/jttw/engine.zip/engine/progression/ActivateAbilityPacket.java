package com.jttw.engine.progression;

import com.jttw.engine.network.NetworkHandler;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * Sent client → server to start or stop an ability activation.
 *
 * <p>Slot mapping for Wukong:
 * <ul>
 *   <li>Slot 0 (R key) — 72 Transformations.  The transform menu is opened client-side;
 *       this packet is NOT sent for that slot (no server notification needed on menu-open).</li>
 *   <li>Slot 1 (F key) — Flight is passive once unlocked; F triggers dimension travel
 *       (Tier 3 only). Action: {@code USE}.</li>
 *   <li>Slot 2 (V key) — Ring of Fire.  Sent with {@code START} on key-down and
 *       {@code STOP} on key-up.</li>
 * </ul>
 *
 * <p>The server routes the packet to the appropriate handler based on the player's
 * subclass and slot mapping.
 */
public class ActivateAbilityPacket {

    public enum Action { USE, START, STOP }

    private final int slot;
    private final Action action;

    public ActivateAbilityPacket(int slot, Action action) {
        this.slot   = slot;
        this.action = action;
    }

    // -----------------------------------------------------------------------
    // Encode / Decode
    // -----------------------------------------------------------------------

    public static void encode(ActivateAbilityPacket pkt, FriendlyByteBuf buf) {
        buf.writeByte(pkt.slot);
        buf.writeByte(pkt.action.ordinal());
    }

    public static ActivateAbilityPacket decode(FriendlyByteBuf buf) {
        int slot    = buf.readByte();
        int ordinal = buf.readByte();
        Action action = Action.values()[Math.min(ordinal, Action.values().length - 1)];
        return new ActivateAbilityPacket(slot, action);
    }

    // -----------------------------------------------------------------------
    // Handle — runs on the server
    // -----------------------------------------------------------------------

    public static void handle(ActivateAbilityPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;
            routeToHandler(player, pkt.slot, pkt.action);
        });
        ctx.get().setPacketHandled(true);
    }

    private static void routeToHandler(ServerPlayer player, int slot, Action action) {
        // Primary: route by reincarnation outcome (set by the full reincarnation flow)
        String outcomeId = player.getPersistentData()
                .getString(com.jttw.engine.reincarnation.AlignmentData.KEY_REINCARNATION_OUTCOME);

        if ("celestial_primate".equals(outcomeId) || "yuan_di".equals(outcomeId)) {
            // Both Primordial outcomes use Wukong ability set for now
            handleWukong(player, slot, action);
            return;
        }

        // Fallback: route by ProgressionClass for players who set their class
        // via debug command without going through reincarnation (e.g. in testing)
        com.jttw.engine.progression.ProgressionClass cls =
                com.jttw.engine.progression.PlayerLevel.getProgressionClass(player);
        if (cls == com.jttw.engine.progression.ProgressionClass.PRIMORDIAL) {
            handleWukong(player, slot, action);
            return;
        }

        // Erlang Shen (Eye of Heaven outcome)
        if ("eye_of_heaven".equals(outcomeId)) {
            handleErlangShen(player, slot, action);
            return;
        }

        // Fallback: HEAVENLY class via debug command
        if (cls == com.jttw.engine.progression.ProgressionClass.HEAVENLY) {
            handleErlangShen(player, slot, action);
            return;
        }

        // TODO: add routing for DIVINE_BEAST, YAOGUAI subclasses
    }

    private static void handleErlangShen(ServerPlayer player, int slot, Action action) {
        switch (slot) {
            case 1 -> {
                // Xiaotian Quan — pure TOGGLE
                if (action == Action.USE) {
                    XiaotianQuanManager.toggle(player);
                }
            }
            case 2 -> {
                // Eye of Heaven — TOGGLE
                if (action == Action.USE) {
                    ErlangShenAbilityHandler.toggleEye(player);
                }
            }
        }
    }

    private static void handleWukong(ServerPlayer player, int slot, Action action) {
        switch (slot) {
            case 1 -> {
                // Shadow Clone — tier 1/2 TOGGLE (USE), tier 3 HELD (START/STOP)
                if (action == Action.USE) {
                    WuCloneManager.toggle(player);
                } else if (action == Action.START) {
                    WuCloneManager.startHold(player);
                } else if (action == Action.STOP) {
                    WuCloneManager.stopHold(player);
                }
            }
            case 2 -> {
                // Ring of Fire
                if (action == Action.START) {
                    WukongAbilityHandler.startRing(player);
                } else if (action == Action.STOP) {
                    WukongAbilityHandler.stopRing(player);
                }
            }
        }
    }
}