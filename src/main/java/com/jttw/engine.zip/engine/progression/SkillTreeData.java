package com.jttw.engine.progression;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.world.entity.player.Player;

import javax.annotation.Nullable;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Reads and writes a player's skill tree state to their persistent NBT data.
 *
 * <p>State stored:
 * <ul>
 *   <li>{@code jttw_skill_points} — unspent points available to spend in the tree.</li>
 *   <li>{@code jttw_skill_nodes}  — NBT list of unlocked node ID strings.</li>
 * </ul>
 *
 * <p><b>Points are awarded in {@link LevelManager} — one point every 5 levels.</b>
 *
 * <p><b>Spending a point:</b>
 * <pre>{@code
 * if (SkillTreeData.tryUnlock(player, "wu_ring_1")) {
 *     // success
 * }
 * }</pre>
 *
 * <p>Gameplay systems check unlock state via {@link #hasNode(Player, String)}.
 * Convenience helpers {@link #getTransformTier}, {@link #getFlightTier}, and
 * {@link #getRingTier} return the highest unlocked tier for Wukong's active abilities.
 */
public final class SkillTreeData {

    private SkillTreeData() {}

    private static final String KEY_POINTS = "jttw_skill_points";
    private static final String KEY_NODES  = "jttw_skill_nodes";

    // -----------------------------------------------------------------------
    // Points
    // -----------------------------------------------------------------------

    public static int getPoints(Player p) {
        return Math.max(0, p.getPersistentData().getInt(KEY_POINTS));
    }

    public static void setPoints(Player p, int points) {
        p.getPersistentData().putInt(KEY_POINTS, Math.max(0, points));
    }

    public static void addPoints(Player p, int amount) {
        setPoints(p, getPoints(p) + amount);
    }

    // -----------------------------------------------------------------------
    // Unlocked nodes
    // -----------------------------------------------------------------------

    /** Returns an immutable snapshot of all unlocked node IDs. */
    public static Set<String> getUnlockedNodes(Player p) {
        CompoundTag pd = p.getPersistentData();
        if (!pd.contains(KEY_NODES, Tag.TAG_LIST)) return Collections.emptySet();
        ListTag list = pd.getList(KEY_NODES, Tag.TAG_STRING);
        Set<String> result = new HashSet<>();
        for (Tag t : list) result.add(t.getAsString());
        return Collections.unmodifiableSet(result);
    }

    public static boolean hasNode(Player p, String nodeId) {
        CompoundTag pd = p.getPersistentData();
        if (!pd.contains(KEY_NODES, Tag.TAG_LIST)) return false;
        ListTag list = pd.getList(KEY_NODES, Tag.TAG_STRING);
        for (Tag t : list) {
            if (t.getAsString().equals(nodeId)) return true;
        }
        return false;
    }

    /** Directly grants a node without costing a skill point. Used by tests / debug. */
    public static void grantNode(Player p, String nodeId) {
        CompoundTag pd = p.getPersistentData();
        ListTag list;
        if (pd.contains(KEY_NODES, Tag.TAG_LIST)) {
            list = pd.getList(KEY_NODES, Tag.TAG_STRING);
        } else {
            list = new ListTag();
        }
        // Avoid duplicates
        for (Tag t : list) {
            if (t.getAsString().equals(nodeId)) return;
        }
        list.add(StringTag.valueOf(nodeId));
        pd.put(KEY_NODES, list);
    }

    // -----------------------------------------------------------------------
    // Unlock (spend a point)
    // -----------------------------------------------------------------------

    /**
     * Resolves a skill node by ID across all registered skill trees.
     * Routes by ID prefix: "wu_" → Wukong, "es_" → Erlang Shen.
     */
    @Nullable
    public static SkillNode resolveNode(String nodeId) {
        if (nodeId.startsWith("wu_")) return WukongSkillTree.get(nodeId);
        if (nodeId.startsWith("es_")) return ErlangShenSkillTree.get(nodeId);
        return null;
    }

    /**
     * Attempts to unlock {@code nodeId} for the player, deducting skill points.
     *
     * <p>Validates:
     * <ol>
     *   <li>The node exists in a registered skill tree.</li>
     *   <li>The player has enough skill points.</li>
     *   <li>All prerequisite nodes are already unlocked.</li>
     *   <li>The node is not already unlocked.</li>
     * </ol>
     *
     * @return {@code true} if the unlock succeeded; {@code false} otherwise.
     */
    public static boolean tryUnlock(Player p, String nodeId) {
        SkillNode node = resolveNode(nodeId);
        if (node == null) return false;

        if (hasNode(p, nodeId)) return false;

        int points = getPoints(p);
        if (points < node.cost()) return false;

        Set<String> unlocked = getUnlockedNodes(p);
        for (String prereq : node.prerequisites()) {
            if (!unlocked.contains(prereq)) return false;
        }

        // All checks passed — deduct and grant
        setPoints(p, points - node.cost());
        grantNode(p, nodeId);
        return true;
    }

    // -----------------------------------------------------------------------
    // Copy on death/clone
    // -----------------------------------------------------------------------

    public static void copyTo(Player from, Player to) {
        CompoundTag src = from.getPersistentData();
        CompoundTag dst = to.getPersistentData();
        if (src.contains(KEY_POINTS)) dst.put(KEY_POINTS, src.get(KEY_POINTS).copy());
        if (src.contains(KEY_NODES))  dst.put(KEY_NODES,  src.get(KEY_NODES).copy());
    }

    // -----------------------------------------------------------------------
    // Convenience — Wukong tier helpers
    // -----------------------------------------------------------------------

    /** Highest unlocked transformation tier (0 = none unlocked). */
    public static int getTransformTier(Player p) {
        return WukongSkillTree.getHighestTier(getUnlockedNodes(p), "wu_transform");
    }

    /** Highest unlocked flight tier (0 = flight not unlocked). */
    public static int getFlightTier(Player p) {
        return WukongSkillTree.getHighestTier(getUnlockedNodes(p), "wu_flight");
    }

    /** Highest unlocked ring-of-fire tier (0 = not unlocked). */
    public static int getRingTier(Player p) {
        return WukongSkillTree.getHighestTier(getUnlockedNodes(p), "wu_ring");
    }

    /** Highest unlocked shadow-clone tier (0 = not unlocked). */
    public static int getCloneTier(Player p) {
        return WukongSkillTree.getHighestTier(getUnlockedNodes(p), "wu_clone");
    }

    // -----------------------------------------------------------------------
    // Convenience — Erlang Shen tier helpers
    // -----------------------------------------------------------------------

    /** Highest unlocked Erlang Shen transformation tier (0 = none). */
    public static int getEsTransformTier(Player p) {
        return ErlangShenSkillTree.getHighestTier(getUnlockedNodes(p), "es_transform");
    }

    /** Highest unlocked Xiaotian Quan ability tier (0 = not unlocked). */
    public static int getXtqTier(Player p) {
        return ErlangShenSkillTree.getHighestTier(getUnlockedNodes(p), "es_xtq");
    }

    /** Highest unlocked Eye of Heaven tier (0 = not unlocked). */
    public static int getEyeTier(Player p) {
        return ErlangShenSkillTree.getHighestTier(getUnlockedNodes(p), "es_eye");
    }

    /** Highest unlocked Erlang Shen flight tier (0 = not unlocked). */
    public static int getEsFlightTier(Player p) {
        return ErlangShenSkillTree.getHighestTier(getUnlockedNodes(p), "es_flight");
    }

    /** Effective Xiaotian Quan growth tier based on Hound Growth passives. */
    public static int getXtqGrowthTier(Player p) {
        Set<String> nodes = getUnlockedNodes(p);
        if (nodes.contains(ErlangShenSkillTree.XTQ_GROWTH_3)) return 3;
        if (nodes.contains(ErlangShenSkillTree.XTQ_GROWTH_2)) return 2;
        if (nodes.contains(ErlangShenSkillTree.XTQ_GROWTH_1)) return 1;
        return 0;
    }
}