package com.jttw.engine.progression;

import com.jttw.engine.JTTWEngine;
import com.jttw.engine.network.NetworkHandler;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Drives Qi regeneration every server tick and keeps the client in sync.
 *
 * <p><b>Regen formula:</b>
 * <pre>
 *   regenPerTick = REGEN_BASE + (will × REGEN_WILL_FACTOR)
 * </pre>
 *
 * <p>Where {@code will} is {@link StatBlock#will()} for the player's current class and level.
 *
 * <p>NOTE: With the new tuning (high-Qi builds reaching ~10k max Qi), we use a
 * less frequent sync interval to avoid packet spam while regenerating.
 *
 * <p><b>To spend Qi from an ability:</b>
 * <pre>{@code
 * if (QiData.spend(player, 5.0f)) {
 *     // ability fires
 *     QiManager.syncNow(player);
 * }
 * }</pre>
 */
@Mod.EventBusSubscriber(modid = JTTWEngine.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class QiManager {
    private QiManager() {}

    // -----------------------------------------------------------------------
    // Tuning constants
    // -----------------------------------------------------------------------

    /**
     * Flat regen per tick regardless of will.
     * Keep small relative to will scaling so WILL still matters.
     */
    private static final float REGEN_BASE = 0.01f;

    /**
     * Additional regen per point of will per tick.
     *
     * Target: "highest base will (230) should scale to ~20 qi/sec at lvl 100"
     * With current WILL scaling, HEAVENLY lvl100 will is ~46.5, so:
     *   0.01 + 46.5 * 0.0215 ≈ 1.01 qi/tick ≈ 20.2 qi/sec
     */
    private static final float REGEN_WILL_FACTOR = 0.0215f;

    /**
     * How many server ticks between sync packets while Qi is regenerating.
     *
     * With max Qi ~10k, syncing every 5 ticks is usually unnecessary network load.
     * 20 ticks = 1 second. This keeps UI responsive enough while cutting spam.
     */
    private static final int SYNC_INTERVAL_TICKS = 20;

    // -----------------------------------------------------------------------
    // Server tick
    // -----------------------------------------------------------------------

    @SubscribeEvent
    public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (!(event.player instanceof ServerPlayer sp)) return;
        if (sp.level().isClientSide) return;

        ProgressionClass cls = PlayerLevel.getProgressionClass(sp);
        if (cls == null) return;

        int level = PlayerLevel.getLevel(sp);
        StatBlock stats = StatBlock.compute(cls, level);

        // Reconcile max Qi every tick — level-ups change it
        float maxQi = (float) stats.qi();
        QiData.setMax(sp, maxQi);

        // Regen
        float current = QiData.getCurrent(sp);
        if (current < maxQi) {
            float regenRate = REGEN_BASE + (float) (stats.will() * REGEN_WILL_FACTOR);
            float next = Math.min(maxQi, current + regenRate);
            QiData.setCurrent(sp, next);

            // Sync on interval while regenerating
            if (sp.tickCount % SYNC_INTERVAL_TICKS == 0) {
                syncNow(sp);
            }
        }
    }

    // -----------------------------------------------------------------------
    // External API
    // -----------------------------------------------------------------------

    /**
     * Force an immediate sync packet for this player.
     * Call this after spending or restoring Qi outside of the normal regen tick.
     */
    public static void syncNow(ServerPlayer player) {
        SyncQiPacket pkt = new SyncQiPacket(
                QiData.getCurrent(player),
                QiData.getMax(player)
        );
        NetworkHandler.sendToPlayer(player, pkt);
    }
}