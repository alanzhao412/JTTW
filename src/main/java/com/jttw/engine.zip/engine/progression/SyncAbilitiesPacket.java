package com.jttw.engine.progression;

import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;

/**
 * Syncs a player's active skill-bar ability list (slot 0, 1, 2) from server to client.
 *
 * <p>Each entry carries the ability ID, display name, how it is activated ({@link AbilityType}),
 * and its current tier — so the HUD renderer and key handlers know exactly how to present
 * and activate the ability.
 *
 * <p>Sent by {@link LevelManager} on login and by {@link SpendSkillPointPacket} when a
 * relevant skill node is unlocked.
 */
public class SyncAbilitiesPacket {

    /** An active ability assigned to one of the three skill-bar slots. */
    public record Entry(String id, String displayName, AbilityType type, int tier) {}

    private final UUID playerId;
    private final List<Entry> abilities;

    public SyncAbilitiesPacket(UUID playerId, List<Entry> abilities) {
        this.playerId  = playerId;
        this.abilities = List.copyOf(abilities);
    }

    // -----------------------------------------------------------------------
    // Encode / Decode
    // -----------------------------------------------------------------------

    public static void encode(SyncAbilitiesPacket pkt, FriendlyByteBuf buf) {
        buf.writeUUID(pkt.playerId);
        buf.writeInt(pkt.abilities.size());
        for (Entry e : pkt.abilities) {
            buf.writeUtf(e.id());
            buf.writeUtf(e.displayName());
            buf.writeByte(e.type().ordinal());
            buf.writeByte(e.tier());
        }
    }

    public static SyncAbilitiesPacket decode(FriendlyByteBuf buf) {
        UUID id    = buf.readUUID();
        int count  = buf.readInt();
        List<Entry> list = new ArrayList<>(count);
        for (int i = 0; i < count; i++) {
            String abilityId   = buf.readUtf();
            String displayName = buf.readUtf();
            int typeOrdinal    = buf.readByte();
            int tier           = buf.readByte();
            AbilityType type   = AbilityType.values()[Math.min(typeOrdinal, AbilityType.values().length - 1)];
            list.add(new Entry(abilityId, displayName, type, tier));
        }
        return new SyncAbilitiesPacket(id, list);
    }

    // -----------------------------------------------------------------------
    // Handle
    // -----------------------------------------------------------------------

    public static void handle(SyncAbilitiesPacket pkt, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> handleClient(pkt));
        ctx.get().setPacketHandled(true);
    }

    @OnlyIn(Dist.CLIENT)
    private static void handleClient(SyncAbilitiesPacket pkt) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        if (!mc.player.getUUID().equals(pkt.playerId)) return;
        com.jttw.engine.client.ClientAbilityData.setAbilities(pkt.abilities);
    }

    // -----------------------------------------------------------------------
    // Server-side builder — constructs from the player's skill tree state
    // -----------------------------------------------------------------------

    /**
     * Sentinel entry for a slot that exists but hasn't been unlocked yet.
     * The HUD renders it as an empty placeholder; key handlers ignore it.
     */
    public static final Entry EMPTY_SLOT = new Entry("", "", AbilityType.PASSIVE, 0);

    /**
     * Builds the skill-bar entry list for the given player.
     *
     * <p>Always returns exactly 3 entries at fixed indices so the key handler and
     * server-side slot routing always agree regardless of what is unlocked:
     * <ul>
     *   <li>Index 0 (R) — 72 Transformations</li>
     *   <li>Index 1 (F) — Flight</li>
     *   <li>Index 2 (V) — Ring of Fire</li>
     * </ul>
     * Locked slots are filled with {@link #EMPTY_SLOT}.
     */
    public static SyncAbilitiesPacket build(net.minecraft.server.level.ServerPlayer player) {
        Set<String> unlocked = SkillTreeData.getUnlockedNodes(player);

        // Fixed 3-slot array — R=0, F=1, V=2
        Entry[] slots = { EMPTY_SLOT, EMPTY_SLOT, EMPTY_SLOT };

        String outcomeId = player.getPersistentData()
                .getString(com.jttw.engine.reincarnation.AlignmentData.KEY_REINCARNATION_OUTCOME);

        // Fallback: if outcome tag missing (e.g. after death before first sync),
        // treat PRIMORDIAL class as celestial_primate so slots are never lost.
        if (outcomeId.isEmpty()) {
            com.jttw.engine.progression.ProgressionClass cls =
                    com.jttw.engine.progression.PlayerLevel.getProgressionClass(player);
            if (cls == com.jttw.engine.progression.ProgressionClass.PRIMORDIAL) {
                outcomeId = "celestial_primate";
            }
        }

        if ("celestial_primate".equals(outcomeId) || "yuan_di".equals(outcomeId)) {
            // Slot 0 (R) — 72 Transformations
            int transformTier = WukongSkillTree.getHighestTier(unlocked, "wu_transform");
            if (transformTier >= 1) {
                slots[0] = new Entry("wu_transform", "72 Transformations",
                        AbilityType.MENU, transformTier);
            }
            // Slot 1 (F) — Shadow Clone (replaced Flight, which is now passive)
            int cloneTier = WukongSkillTree.getHighestTier(unlocked, "wu_clone");
            if (cloneTier >= 1) {
                AbilityType cloneType = (cloneTier >= 3) ? AbilityType.HELD : AbilityType.TOGGLE;
                slots[1] = new Entry("wu_clone", "Shadow Clone", cloneType, cloneTier);
            }
            // Slot 2 (V) — Ring of Fire
            int ringTier = WukongSkillTree.getHighestTier(unlocked, "wu_ring");
            if (ringTier >= 1) {
                slots[2] = new Entry("wu_ring", "Ring of Fire", AbilityType.HELD, ringTier);
            }
        }

        // Erlang Shen (Eye of Heaven outcome)
        if (outcomeId.isEmpty()) {
            com.jttw.engine.progression.ProgressionClass cls2 =
                    com.jttw.engine.progression.PlayerLevel.getProgressionClass(player);
            if (cls2 == com.jttw.engine.progression.ProgressionClass.HEAVENLY) {
                outcomeId = "eye_of_heaven";
            }
        }
        if ("eye_of_heaven".equals(outcomeId)) {
            // Slot 0 (R) — 72 Transformations
            int esTransformTier = ErlangShenSkillTree.getHighestTier(unlocked, "es_transform");
            if (esTransformTier >= 1) {
                slots[0] = new Entry("es_transform", "72 Transformations",
                        AbilityType.MENU, esTransformTier);
            }
            // Slot 1 (F) — Xiaotian Quan
            int xtqTier = ErlangShenSkillTree.getHighestTier(unlocked, "es_xtq");
            if (xtqTier >= 1) {
                slots[1] = new Entry("es_xtq", "Xiaotian Quan",
                        AbilityType.TOGGLE, xtqTier);
            }
            // Slot 2 (V) — Eye of Heaven
            int eyeTier = ErlangShenSkillTree.getHighestTier(unlocked, "es_eye");
            if (eyeTier >= 1) {
                slots[2] = new Entry("es_eye", "Eye of Heaven",
                        AbilityType.TOGGLE, eyeTier);
            }
        }

        return new SyncAbilitiesPacket(player.getUUID(), java.util.Arrays.asList(slots));
    }
}