package com.jttw.engine.progression;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;

/**
 * Lightweight custom entity for Wukong shadow clones.
 *
 * Extends PathfinderMob (NOT Monster), so:
 *   - Iron golems won't target it
 *   - No zombie model / zombie arm animation
 *   - No zombie sounds
 *   - Clean goal slate via registerGoals()
 *
 * Goals are registered here at construction time, so they survive
 * chunk save/load without needing to be re-applied.
 */
public class WuCloneEntity extends PathfinderMob {

    public WuCloneEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    /**
     * Wolf-style goals are registered once at construction.
     * WuCloneManager provides the goal instances.
     */
    @Override
    protected void registerGoals() {
        WuCloneManager.registerCloneGoals(this);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.ATTACK_DAMAGE, 2.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.ARMOR, 0.0)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    // Silent — no zombie groaning
    @Nullable @Override protected SoundEvent getAmbientSound() { return null; }
    @Nullable @Override protected SoundEvent getHurtSound(DamageSource src) { return null; }
    @Nullable @Override protected SoundEvent getDeathSound() { return null; }

    // Don't drop loot
    @Override protected boolean shouldDropLoot() { return false; }

    // Don't despawn (we manage lifetime via Qi drain / dismiss)
    @Override public boolean removeWhenFarAway(double dist) { return false; }

    // Don't persist to disk — clones are temporary summons
    @Override public boolean shouldBeSaved() { return false; }
}