package com.jttw.engine.progression;

/**
 * Form evolution stages for the Divine Beast class.
 *
 * <p>Divine Beasts progress through three predefined form phases rather than
 * the ability-expansion model used by Heavenly or the explicit spike model of Yaoguai.
 * Each stage transition is a meaningful identity shift tied to their domain.
 *
 * <p>Other classes technically have a form stage (stored in {@link PlayerLevel#getFormStage}),
 * but only DIVINE_BEAST has structured phase labels.  Primordial's form shifts
 * are represented by ability unlocks ({@code primal_form}, {@code primordial_origin}) instead.
 *
 * <p><b>Stage transitions fire automatically in {@link LevelManager} on level-up.</b>
 * Wire visual/model changes by checking {@link PlayerLevel#getFormStage(net.minecraft.world.entity.player.Player)}
 * in your rendering or transformation systems.
 */
public enum FormStage {

    /** Stages 0–39: Base identity established.  Lesser domain, nascent power. */
    LESSER(0, 0,
            "Lesser Form",
            "You stir, young beast.  The land begins to recognise your presence."),

    /** Stages 40–79: Intermediate evolution.  Domain authority solidifies. */
    INTERMEDIATE(1, 40,
            "Intermediate Form",
            "You have shed your lesser shell.  Your domain bends to your will."),

    /** Stage 80–99: Sovereign form.  Full domain expression, apex predator. */
    SOVEREIGN(2, 80,
            "Sovereign Form",
            "You stand as sovereign.  Mountains tremble.  Rivers yield."),

    /** Stage 100: True apex.  Mythological legend acknowledged by heaven itself. */
    APEX(3, 100,
            "Apex Domain",
            "Heaven has written your name.  You are legend.");

    /** Index stored in {@link PlayerLevel#getFormStage}. */
    public final int stageIndex;

    /** Minimum level required to enter this stage. */
    public final int requiredLevel;

    public final String displayName;
    public final String transitionMessage;

    FormStage(int stageIndex, int requiredLevel, String displayName, String transitionMessage) {
        this.stageIndex = stageIndex;
        this.requiredLevel = requiredLevel;
        this.displayName = displayName;
        this.transitionMessage = transitionMessage;
    }

    /**
     * Returns the highest form stage the player has earned at the given level.
     * Used by {@link LevelManager} to check whether a stage transition should fire.
     */
    public static FormStage forLevel(int level) {
        FormStage result = LESSER;
        for (FormStage stage : values()) {
            if (level >= stage.requiredLevel) result = stage;
        }
        return result;
    }

    /**
     * Returns the form stage corresponding to a stored stage index.
     * Falls back to LESSER for unknown values.
     */
    public static FormStage fromIndex(int index) {
        for (FormStage stage : values()) {
            if (stage.stageIndex == index) return stage;
        }
        return LESSER;
    }
}