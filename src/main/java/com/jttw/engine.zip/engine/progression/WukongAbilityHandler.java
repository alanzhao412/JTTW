package com.jttw.engine.progression;

import com.jttw.engine.JTTWEngine;
import com.jttw.engine.network.NetworkHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Server-side handler for Wukong-specific active abilities.
 */
@Mod.EventBusSubscriber(modid = JTTWEngine.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class WukongAbilityHandler {

    private WukongAbilityHandler() {}

    // -----------------------------------------------------------------------
    // Ring of Fire state
    // -----------------------------------------------------------------------

    private static final Set<UUID> ACTIVE_RINGS = new HashSet<>();

    // Ring tuning
    private static final double RING_RADIUS         = 5.0;
    private static final float  PUSH_FORCE_T1       = 1.4f;
    private static final float  PUSH_FORCE_T3       = 2.8f;
    private static final float  QI_DRAIN_PER_TICK   = 0.1f;   // 2/sec
    private static final float  QI_REGEN_T2_TICK    = 0.15f;  // 3/sec
    private static final int    FIRE_TICKS_T1       = 40;     // 2s
    private static final int    FIRE_TICKS_T3       = 60;     // 3s
    private static final float  RING_DAMAGE         = 1.0f;   // 0.5 hearts

    public static void startRing(ServerPlayer player) {
        if (SkillTreeData.getRingTier(player) < 1) return;

        ACTIVE_RINGS.add(player.getUUID());

        // ✅ tell clients to render ring for this player
        NetworkHandler.sendToPlayer(player, new SyncRingStatePacket(player.getUUID(), true));
        NetworkHandler.sendToTrackingPlayers(player, new SyncRingStatePacket(player.getUUID(), true));
    }

    public static void stopRing(ServerPlayer player) {
        ACTIVE_RINGS.remove(player.getUUID());

        // ✅ tell clients to stop rendering ring for this player
        NetworkHandler.sendToPlayer(player, new SyncRingStatePacket(player.getUUID(), false));
        NetworkHandler.sendToTrackingPlayers(player, new SyncRingStatePacket(player.getUUID(), false));
    }

    // -----------------------------------------------------------------------
    // Server tick — ring of fire
    // -----------------------------------------------------------------------

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        MinecraftServer server = event.getServer();
        Set<UUID> toRemove = new HashSet<>();

        for (UUID uuid : ACTIVE_RINGS) {
            ServerPlayer player = server.getPlayerList().getPlayer(uuid);
            if (player == null) {
                toRemove.add(uuid);
                continue;
            }

            // Drain Qi — if depleted, deactivate
            if (!QiData.spend(player, QI_DRAIN_PER_TICK)) {
                toRemove.add(uuid);

                NetworkHandler.sendToPlayer(player,
                        new SyncCooldownPacket(uuid, "wu_ring_forced_stop", 0, 1));

                // ✅ also force visual OFF
                NetworkHandler.sendToPlayer(player, new SyncRingStatePacket(uuid, false));
                NetworkHandler.sendToTrackingPlayers(player, new SyncRingStatePacket(uuid, false));
                continue;
            }

            int tier = SkillTreeData.getRingTier(player);

            boolean applyThisTick = (tier >= 3) || (player.tickCount % 2 == 0);
            if (applyThisTick) {
                applyRingEffect(player, tier);
            }

            if (tier >= 2) {
                QiData.restore(player, QI_REGEN_T2_TICK);
            }

            if (player.tickCount % 10 == 0) {
                NetworkHandler.sendToPlayer(player,
                        new SyncQiPacket(
                                QiData.getCurrent(player),
                                QiData.getMax(player)
                        ));
            }
        }

        ACTIVE_RINGS.removeAll(toRemove);
    }

    private static void applyRingEffect(ServerPlayer player, int tier) {
        Vec3 center = player.position().add(0, 1.0, 0);
        float pushForce = (tier >= 3) ? PUSH_FORCE_T3 : PUSH_FORCE_T1;
        int fireTicks   = (tier >= 3) ? FIRE_TICKS_T3 : FIRE_TICKS_T1;

        AABB searchBox = new AABB(center, center).inflate(RING_RADIUS + 1.5);
        List<LivingEntity> nearby = player.level().getEntitiesOfClass(
                LivingEntity.class,
                searchBox,
                e -> e != player && e.distanceTo(player) <= RING_RADIUS
        );

        DamageSource fireSrc = player.level().damageSources().onFire();

        for (LivingEntity entity : nearby) {
            Vec3 dir = entity.position().subtract(center);

            if (dir.lengthSqr() < 1.0e-6) {
                dir = new Vec3(1, 0, 0);
            } else {
                dir = dir.normalize();
            }

            Vec3 current = entity.getDeltaMovement();
            entity.setDeltaMovement(
                    current.x + dir.x * pushForce,
                    current.y + 0.3,
                    current.z + dir.z * pushForce
            );

            entity.setRemainingFireTicks(fireTicks);
            entity.hurt(fireSrc, RING_DAMAGE);

            if (tier >= 3) {
                double dist = entity.distanceTo(player);
                if (dist < RING_RADIUS - 0.5) {
                    Vec3 safePos = center.add(dir.scale(RING_RADIUS + 0.5));
                    entity.teleportTo(safePos.x, safePos.y, safePos.z);
                }
            }
        }
    }

    // -----------------------------------------------------------------------
    // Dimension cycling (Flight Tier 3)
    // -----------------------------------------------------------------------

    @SuppressWarnings("unchecked")
    private static final ResourceKey<Level>[] DIMENSION_CYCLE =
            new ResourceKey[]{
                    Level.OVERWORLD,
                    Level.NETHER,
                    Level.END
            };

    public static void cycleDimension(ServerPlayer player) {
        if (SkillTreeData.getFlightTier(player) < 3) return;

        ResourceKey<Level> current = player.level().dimension();
        ResourceKey<Level> next = Level.OVERWORLD;

        for (int i = 0; i < DIMENSION_CYCLE.length; i++) {
            if (DIMENSION_CYCLE[i].equals(current)) {
                next = DIMENSION_CYCLE[(i + 1) % DIMENSION_CYCLE.length];
                break;
            }
        }

        MinecraftServer server = player.getServer();
        if (server == null) return;

        ServerLevel targetLevel = server.getLevel(next);
        if (targetLevel == null) return;

        if (!QiData.spend(player, 20f)) {
            player.sendSystemMessage(
                    net.minecraft.network.chat.Component.literal("§cNot enough Qi to travel dimensions."));
            return;
        }

        BlockPos targetPos = targetLevel.getHeightmapPos(
                net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                player.blockPosition()
        );

        player.teleportTo(targetLevel,
                targetPos.getX() + 0.5,
                targetPos.getY() + 1.0,
                targetPos.getZ() + 0.5,
                player.getYRot(),
                player.getXRot()
        );

        com.jttw.engine.flight.JTTWFlight.setUniversalFlight(player, true);
        com.jttw.engine.flight.JTTWFlight.setFlightSpeedTier(player, 3);
    }

    // -----------------------------------------------------------------------
    // Logout cleanup
    // -----------------------------------------------------------------------

    @SubscribeEvent
    public static void onPlayerLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        ACTIVE_RINGS.remove(event.getEntity().getUUID());
    }
}