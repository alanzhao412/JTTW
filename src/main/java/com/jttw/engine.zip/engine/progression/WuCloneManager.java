package com.jttw.engine.progression;

import com.jttw.engine.JTTWEngine;
import com.jttw.engine.network.NetworkHandler;
import net.minecraft.network.chat.Component;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.TargetGoal;
import net.minecraft.world.entity.ai.targeting.TargetingConditions;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.*;

/**
 * Manages Sun Wukong's Shadow Clone ability.
 *
 * Clones are WuCloneEntity instances (extends PathfinderMob, NOT Monster) with
 * wolf-style companion goals:
 *   - Attack whatever the owner attacks
 *   - Defend the owner when they take damage
 *   - Retaliate when the clone itself is hit
 *   - Follow the owner at a comfortable distance
 *
 * Because they're not Monsters, iron golems and other mob-targeting systems ignore them.
 *
 * Tier 1 and 2: TOGGLE — summons 1 or 2 clones on press, dismisses on second press.
 * Tier 3: HELD — press once to summon/dismiss, hold to spawn one more per second.
 */
@Mod.EventBusSubscriber(modid = JTTWEngine.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class WuCloneManager {

    private WuCloneManager() {}

    public static final String CLONE_TAG       = "jttw_wu_clone";
    public static final String CLONE_OWNER_TAG = "jttw_wu_clone_owner";
    public static final String CLONE_QI_TAG    = "jttw_wu_clone_qi";
    public static final String CLONE_WILL_TAG  = "jttw_wu_clone_will";

    private static final float  QI_COST_SUMMON              = 10f;
    private static final float  QI_DRAIN_PER_TICK_PER_CLONE = 0.05f;
    private static final double FOLLOW_TELEPORT_DIST        = 18.0;
    private static final int    FOLLOW_SPREAD               = 2;
    private static final int    SPAWN_INTERVAL_TICKS        = 20;
    private static final int    MAX_CLONES_T3               = 9;

    private static final Map<UUID, List<UUID>> OWNER_TO_CLONES = new HashMap<>();
    private static final Map<UUID, Integer>    HOLD_TICKS      = new HashMap<>();

    // =========================================================================
    // Public API
    // =========================================================================

    public static void toggle(ServerPlayer player) {
        if (OWNER_TO_CLONES.containsKey(player.getUUID())) {
            dismiss(player);
        } else {
            int tier = SkillTreeData.getCloneTier(player);
            if (tier < 1) return;
            for (int i = 0; i < tier; i++) summonOne(player);
        }
    }

    public static void startHold(ServerPlayer player) {
        if (SkillTreeData.getCloneTier(player) < 3) return;
        if (OWNER_TO_CLONES.containsKey(player.getUUID())) {
            dismiss(player);
            return;
        }
        HOLD_TICKS.put(player.getUUID(), 0);
        summonOne(player);
    }

    public static void stopHold(ServerPlayer player) {
        HOLD_TICKS.remove(player.getUUID());
    }

    public static void dismiss(ServerPlayer player) {
        HOLD_TICKS.remove(player.getUUID());
        List<UUID> ids = OWNER_TO_CLONES.remove(player.getUUID());
        if (ids == null) return;
        removeCloneEntities(player.serverLevel(), ids);
        player.sendSystemMessage(Component.literal("§6Shadow clones dismissed."));
    }

    public static boolean isActive(UUID ownerId) {
        List<UUID> c = OWNER_TO_CLONES.get(ownerId);
        return c != null && !c.isEmpty();
    }

    // =========================================================================
    // Goal registration (called by WuCloneEntity.registerGoals)
    // =========================================================================

    /**
     * Installs wolf-style companion AI on the given mob.
     * Called from {@link WuCloneEntity#registerGoals()} at construction time.
     */
    public static void registerCloneGoals(PathfinderMob mob) {
        // Behaviour goals
        mob.goalSelector.addGoal(1, new FloatGoal(mob));
        mob.goalSelector.addGoal(2, new MeleeAttackGoal(mob, 1.2, true));
        mob.goalSelector.addGoal(3, new CloneFollowOwnerGoal(mob, 1.1, 5.0f, 2.5f));
        mob.goalSelector.addGoal(4, new WaterAvoidingRandomStrollGoal(mob, 0.8));
        mob.goalSelector.addGoal(5, new LookAtPlayerGoal(mob, Player.class, 8.0F));
        mob.goalSelector.addGoal(5, new RandomLookAroundGoal(mob));

        // Target-selection goals (wolf order)
        mob.targetSelector.addGoal(1, new CloneOwnerHurtByGoal(mob));
        mob.targetSelector.addGoal(2, new CloneOwnerHurtGoal(mob));
        mob.targetSelector.addGoal(3, new HurtByTargetGoal(mob));
    }

    // =========================================================================
    // Tick / upkeep
    // =========================================================================

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;

        MinecraftServer server = net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;

        for (ServerPlayer player : server.getPlayerList().getPlayers()) {
            UUID ownerId = player.getUUID();

            // Tier 3: held spawning
            if (HOLD_TICKS.containsKey(ownerId)) {
                int t = HOLD_TICKS.get(ownerId) + 1;
                HOLD_TICKS.put(ownerId, t);
                if (t % SPAWN_INTERVAL_TICKS == 0) {
                    summonOne(player);
                }
            }

            List<UUID> cloneIds = OWNER_TO_CLONES.get(ownerId);
            if (cloneIds == null || cloneIds.isEmpty()) continue;

            // Qi drain
            float cost = (float) (cloneIds.size() * QI_DRAIN_PER_TICK_PER_CLONE);
            if (!QiData.spend(player, cost)) {
                dismiss(player);
                player.sendSystemMessage(Component.literal("§cNot enough Qi to maintain clones."));
                continue;
            }

            // Resolve living clones, clean up dead/missing ones
            ServerLevel level = player.serverLevel();
            List<Entity> clones = resolveClones(level, cloneIds);

            if (clones.size() != cloneIds.size()) {
                List<UUID> newList = new ArrayList<>();
                for (Entity ent : clones) newList.add(ent.getUUID());
                if (newList.isEmpty()) {
                    OWNER_TO_CLONES.remove(ownerId);
                } else {
                    OWNER_TO_CLONES.put(ownerId, newList);
                }
            }

            int idx = 0;
            for (Entity ent : clones) {
                if (!(ent instanceof WuCloneEntity clone)) continue;

                // Sync held item periodically
                if ((server.getTickCount() & 7) == 0) {
                    syncHeldItem(clone, player);
                }

                // Safety: if a clone ever somehow targets the owner, clear it
                if (clone.getTarget() == player) {
                    clone.setTarget(null);
                }

                // Teleport if way too far (goal-based follow handles normal range)
                double dist = clone.position().distanceTo(player.position());
                if (dist > FOLLOW_TELEPORT_DIST) {
                    double angle = (Math.PI * 2.0 / Math.max(1, clones.size())) * idx;
                    double tx = player.getX() + Math.cos(angle) * FOLLOW_SPREAD;
                    double tz = player.getZ() + Math.sin(angle) * FOLLOW_SPREAD;
                    clone.teleportTo(tx, player.getY(), tz);
                }
                idx++;
            }
        }
    }

    // =========================================================================
    // Combat rules
    // =========================================================================

    @SubscribeEvent
    public static void onPlayerAttacks(AttackEntityEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer player)) return;
        if (!(e.getTarget() instanceof LivingEntity target)) return;
        if (isClone(target) && isOwner(target, player)) {
            e.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onCloneAttacks(LivingAttackEvent e) {
        if (!(e.getSource().getEntity() instanceof WuCloneEntity)) return;
    }

    @SubscribeEvent
    public static void onCloneHurt(LivingHurtEvent e) {
        if (!(e.getEntity() instanceof WuCloneEntity clone)) return;
        ServerPlayer owner = getOwnerPlayer(clone);
        if (owner == null) return;
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer player)) return;
        dismiss(player);
    }

    // =========================================================================
    // Summon / apply
    // =========================================================================

    private static void summonOne(ServerPlayer player) {
        List<UUID> existing = OWNER_TO_CLONES.get(player.getUUID());
        int currentCount = (existing != null) ? existing.size() : 0;

        if (SkillTreeData.getCloneTier(player) >= 3 && currentCount >= MAX_CLONES_T3) return;

        if (!QiData.spend(player, QI_COST_SUMMON)) {
            player.sendSystemMessage(Component.literal("§cNot enough Qi to summon a clone."));
            HOLD_TICKS.remove(player.getUUID());
            return;
        }

        ServerLevel level = player.serverLevel();
        WuCloneEntity clone = new WuCloneEntity(JTTWEngine.WU_CLONE.get(), level);

        // Encode owner UUID in custom name so client-side renderer can look up the skin
        clone.setCustomName(Component.literal("jttw_clone:" + player.getUUID()));
        clone.setCustomNameVisible(false);

        double angle  = (Math.PI * 2.0 / Math.max(1, currentCount + 1)) * currentCount;
        double spawnX = player.getX() + Math.cos(angle) * FOLLOW_SPREAD;
        double spawnZ = player.getZ() + Math.sin(angle) * FOLLOW_SPREAD;
        clone.moveTo(spawnX, player.getY(), spawnZ, player.getYRot(), 0f);

        CompoundTag pd = clone.getPersistentData();
        pd.putBoolean(CLONE_TAG, true);
        pd.putUUID(CLONE_OWNER_TAG, player.getUUID());

        applyPlayerStats(clone, player);
        syncHeldItem(clone, player);

        clone.setDropChance(net.minecraft.world.entity.EquipmentSlot.MAINHAND, 0f);
        clone.setCanPickUpLoot(false);
        clone.setPersistenceRequired();

        clone.setTarget(null);

        level.addFreshEntity(clone);
        OWNER_TO_CLONES.computeIfAbsent(player.getUUID(), k -> new ArrayList<>()).add(clone.getUUID());

        int total = OWNER_TO_CLONES.get(player.getUUID()).size();
        String word = total == 1 ? "clone" : "clones";
        player.sendSystemMessage(Component.literal("§a" + total + " shadow " + word + " active."));
    }

    private static void applyPlayerStats(WuCloneEntity clone, ServerPlayer player) {
        var maxHp = clone.getAttribute(Attributes.MAX_HEALTH);
        if (maxHp != null) maxHp.setBaseValue(20.0);
        clone.setHealth(20.0f);

        double playerAtk = player.getAttributeValue(Attributes.ATTACK_DAMAGE);
        double playerDef = player.getAttributeValue(Attributes.ARMOR);

        var atk = clone.getAttribute(Attributes.ATTACK_DAMAGE);
        if (atk != null) atk.setBaseValue(Math.min(20.0, Math.max(1.0, playerAtk)));

        var armor = clone.getAttribute(Attributes.ARMOR);
        if (armor != null) armor.setBaseValue(Math.min(20.0, Math.max(0.0, playerDef)));

        var spd = clone.getAttribute(Attributes.MOVEMENT_SPEED);
        if (spd != null) spd.setBaseValue(Math.max(0.3, player.getAttributeValue(Attributes.MOVEMENT_SPEED)));

        CompoundTag pd = clone.getPersistentData();
        pd.putFloat(CLONE_QI_TAG, QiData.getCurrent(player) * 0.25f);
        ProgressionClass cls = PlayerLevel.getProgressionClass(player);
        if (cls != null) {
            float will = (float) StatBlock.compute(cls, PlayerLevel.getLevel(player)).will();
            pd.putFloat(CLONE_WILL_TAG, will * 0.25f);
        }
    }

    private static void syncHeldItem(WuCloneEntity clone, ServerPlayer player) {
        ItemStack held = player.getMainHandItem().copy();
        clone.setItemSlot(net.minecraft.world.entity.EquipmentSlot.MAINHAND, held);
    }

    // =========================================================================
    // Helpers
    // =========================================================================

    static boolean isClone(LivingEntity ent) {
        return ent.getPersistentData().getBoolean(CLONE_TAG);
    }

    private static boolean isOwner(LivingEntity ent, ServerPlayer player) {
        CompoundTag pd = ent.getPersistentData();
        return pd.hasUUID(CLONE_OWNER_TAG) && pd.getUUID(CLONE_OWNER_TAG).equals(player.getUUID());
    }

    private static ServerPlayer getOwnerPlayer(WuCloneEntity clone) {
        CompoundTag pd = clone.getPersistentData();
        if (!pd.hasUUID(CLONE_OWNER_TAG)) return null;
        UUID ownerId = pd.getUUID(CLONE_OWNER_TAG);
        if (!(clone.level() instanceof ServerLevel sl)) return null;
        return sl.getServer().getPlayerList().getPlayer(ownerId);
    }

    static boolean isAllyClone(LivingEntity entity, UUID ownerId) {
        if (!entity.getPersistentData().getBoolean(CLONE_TAG)) return false;
        var pd = entity.getPersistentData();
        return pd.hasUUID(CLONE_OWNER_TAG)
                && pd.getUUID(CLONE_OWNER_TAG).equals(ownerId);
    }

    static ServerPlayer resolveOwner(Mob mob) {
        var pd = mob.getPersistentData();
        if (!pd.hasUUID(CLONE_OWNER_TAG)) return null;
        UUID ownerId = pd.getUUID(CLONE_OWNER_TAG);
        if (!(mob.level() instanceof ServerLevel sl)) return null;
        return sl.getServer().getPlayerList().getPlayer(ownerId);
    }

    private static List<Entity> resolveClones(ServerLevel level, List<UUID> ids) {
        List<Entity> out = new ArrayList<>();
        for (UUID id : ids) {
            Entity e = level.getEntity(id);
            if (e != null) out.add(e);
        }
        return out;
    }

    private static void removeCloneEntities(ServerLevel level, List<UUID> ids) {
        for (UUID id : ids) {
            Entity e = level.getEntity(id);
            if (e != null) e.discard();
        }
    }

    // =========================================================================
    // Inner goal: defend owner (something hurt the owner → retaliate)
    // =========================================================================

    private static final class CloneOwnerHurtByGoal extends TargetGoal {

        private final Mob clone;
        private LivingEntity attacker;
        private int timestamp;

        CloneOwnerHurtByGoal(Mob clone) {
            super(clone, false);
            this.clone = clone;
            this.setFlags(EnumSet.of(Flag.TARGET));
        }

        @Override
        public boolean canUse() {
            ServerPlayer owner = resolveOwner(clone);
            if (owner == null) return false;

            this.attacker = owner.getLastHurtByMob();
            int ts = owner.getLastHurtByMobTimestamp();
            if (ts == this.timestamp || this.attacker == null) return false;
            if (this.attacker == owner) return false;
            if (isAllyClone(this.attacker, owner.getUUID())) return false;

            return this.canAttack(this.attacker, TargetingConditions.DEFAULT);
        }

        @Override
        public boolean canContinueToUse() {
            return this.clone.getTarget() != null && this.clone.getTarget().isAlive();
        }

        @Override
        public void start() {
            this.clone.setTarget(this.attacker);
            ServerPlayer owner = resolveOwner(clone);
            if (owner != null) this.timestamp = owner.getLastHurtByMobTimestamp();
            super.start();
        }
    }

    // =========================================================================
    // Inner goal: attack owner's target (owner hit something → pile on)
    // =========================================================================

    private static final class CloneOwnerHurtGoal extends TargetGoal {

        private final Mob clone;
        private LivingEntity target;
        private int timestamp;

        CloneOwnerHurtGoal(Mob clone) {
            super(clone, false);
            this.clone = clone;
            this.setFlags(EnumSet.of(Flag.TARGET));
        }

        @Override
        public boolean canUse() {
            ServerPlayer owner = resolveOwner(clone);
            if (owner == null) return false;

            this.target = owner.getLastHurtMob();
            int ts = owner.getLastHurtMobTimestamp();
            if (ts == this.timestamp || this.target == null) return false;
            if (this.target == owner) return false;
            if (isAllyClone(this.target, owner.getUUID())) return false;

            return this.canAttack(this.target, TargetingConditions.DEFAULT);
        }

        @Override
        public boolean canContinueToUse() {
            return this.clone.getTarget() != null && this.clone.getTarget().isAlive();
        }

        @Override
        public void start() {
            this.clone.setTarget(this.target);
            ServerPlayer owner = resolveOwner(clone);
            if (owner != null) this.timestamp = owner.getLastHurtMobTimestamp();
            super.start();
        }
    }

    // =========================================================================
    // Inner goal: follow owner (wolf-style pathfinding)
    // =========================================================================

    private static final class CloneFollowOwnerGoal extends Goal {

        private final Mob clone;
        private final double speedModifier;
        private final float startDist;
        private final float stopDist;
        private ServerPlayer owner;
        private int pathRecalcCountdown;

        CloneFollowOwnerGoal(Mob clone, double speedModifier, float startDist, float stopDist) {
            this.clone = clone;
            this.speedModifier = speedModifier;
            this.startDist = startDist;
            this.stopDist = stopDist;
            this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            ServerPlayer player = resolveOwner(clone);
            if (player == null || player.isSpectator()) return false;
            if (clone.distanceToSqr(player) < (double) (startDist * startDist)) return false;
            this.owner = player;
            return true;
        }

        @Override
        public boolean canContinueToUse() {
            if (owner == null || !owner.isAlive()) return false;
            if (clone.getNavigation().isDone()) return false;
            return clone.distanceToSqr(owner) > (double) (stopDist * stopDist);
        }

        @Override
        public void start() {
            this.pathRecalcCountdown = 0;
            clone.getNavigation().setSpeedModifier(speedModifier);
        }

        @Override
        public void stop() {
            this.owner = null;
            clone.getNavigation().stop();
        }

        @Override
        public void tick() {
            clone.getLookControl().setLookAt(owner, 10.0F, (float) clone.getMaxHeadXRot());
            if (--pathRecalcCountdown <= 0) {
                pathRecalcCountdown = this.adjustedTickDelay(10);
                clone.getNavigation().moveTo(owner, speedModifier);
            }
        }
    }
}