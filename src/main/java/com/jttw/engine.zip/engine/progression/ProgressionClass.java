package com.jttw.engine.progression;

import com.jttw.engine.reincarnation.ReincarnationOutcome;

import javax.annotation.Nullable;

/**
 * The four mythological class archetypes.
 *
 * <p>Each class defines:
 * <ul>
 *   <li>{@link #bst} — Base Stat Total.  The ceiling of raw power, distributed across HP/ATK/DEF/SPD.</li>
 *   <li>{@link #growthRate} — The XP-to-level curve.  Shapes how hard each level is to reach.</li>
 * </ul>
 *
 * <p>The actual stat values at any level are computed by {@link StatBlock#compute(ProgressionClass, int)}.
 */
public enum ProgressionClass {

    /**
     * Highest BST ceiling (1000).  Punishing early game; dramatically outscales all
     * other classes after level 50.  Form shifts at major milestones.
     * Designed as a long-term investment.
     */
    PRIMORDIAL(1000, GrowthRate.ERRATIC),

    /**
     * Naturally strong (BST 900).  Stable, consistent scaling curve.
     * Power unlocks tied to evolutionary form phases (lesser → intermediate → sovereign).
     * Domain-based identity.
     */
    DIVINE_BEAST(900, GrowthRate.MEDIUM_FAST),

    /**
     * Widest utility toolkit (BST 700, variable effective power).
     * Ability-expansion focused.  Some archetypes are combat-oriented;
     * higher-tier forms gain perception and authority advantages.
     */
    HEAVENLY(700, GrowthRate.MEDIUM),

    /**
     * Ability-focused power spikes (BST 750).  Lower raw floor.
     * Strong transformation mechanics.  Explosive mid-to-late game power bursts
     * at spike milestones (30/50/70/90).
     */
    YAOGUAI(750, GrowthRate.FLUCTUATING);

    /** Sum of all base stats.  Feeds {@link BaseStats} distribution. */
    public final int bst;

    /** XP growth curve that determines leveling speed. */
    public final GrowthRate growthRate;

    ProgressionClass(int bst, GrowthRate growthRate) {
        this.bst = bst;
        this.growthRate = growthRate;
    }

    // -----------------------------------------------------------------------
    // Mapping from reincarnation system
    // -----------------------------------------------------------------------

    /** Derive the class from a reincarnation outcome. */
    public static ProgressionClass fromOutcome(ReincarnationOutcome outcome) {
        return switch (outcome) {
            case CELESTIAL_PRIMATE,
                 YUAN_DI                                  -> PRIMORDIAL;

            case EYE_OF_HEAVEN,
                 THIRD_LOTUS_PRINCE,
                 MARSHAL_HEAVENLY_CANOPY                  -> HEAVENLY;

            case GARUDA,
                 DRAGON,
                 NINE_TAILED_FOX                          -> DIVINE_BEAST;

            case BULL_DEMON_KING,
                 CHILD_DEMON,
                 SAURIAN_DEMON_KING                       -> YAOGUAI;
        };
    }

    /** Parse from a saved NBT string.  Returns null if unrecognised. */
    @Nullable
    public static ProgressionClass parse(String name) {
        if (name == null || name.isBlank()) return null;
        for (ProgressionClass c : values()) {
            if (c.name().equalsIgnoreCase(name.trim())) return c;
        }
        return null;
    }
}