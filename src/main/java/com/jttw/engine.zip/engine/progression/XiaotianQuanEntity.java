package com.jttw.engine.progression;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;

/**
 * Erlang Shen's celestial hound companion — Xiaotian Quan (啸天犬).
 *
 * <p>Extends PathfinderMob (NOT Monster), so iron golems won't target it.
 * Uses wolf sounds. Goals are registered by {@link XiaotianQuanManager}.
 * Stats are overridden at summon time based on the player's Hound Growth tier.
 */
public class XiaotianQuanEntity extends PathfinderMob {

    public XiaotianQuanEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    @Override
    protected void registerGoals() {
        XiaotianQuanManager.registerCompanionGoals(this);
    }

    /**
     * Base attributes (Tier 0 defaults). The manager overrides these at summon
     * time based on the owner's Hound Growth skill tree tier.
     */
    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30.0)
                .add(Attributes.ATTACK_DAMAGE, 4.0)
                .add(Attributes.MOVEMENT_SPEED, 0.35)
                .add(Attributes.ARMOR, 2.0)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    // Wolf sounds for the celestial hound
    @Nullable @Override protected SoundEvent getAmbientSound() { return SoundEvents.WOLF_AMBIENT; }
    @Nullable @Override protected SoundEvent getHurtSound(DamageSource src) { return SoundEvents.WOLF_HURT; }
    @Nullable @Override protected SoundEvent getDeathSound() { return SoundEvents.WOLF_DEATH; }

    @Override protected boolean shouldDropLoot() { return false; }
    @Override public boolean removeWhenFarAway(double dist) { return false; }
    @Override public boolean shouldBeSaved() { return false; }
}
